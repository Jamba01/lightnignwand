package com.lightningwand;

import com.lightningwand.item.LightningWandItem;
import net.fabricmc.api.ModInitializer;
import net.fabricmc.fabric.api.item.v1.FabricItemSettings;
import net.fabricmc.fabric.api.itemgroup.v1.ItemGroupEvents;
import net.minecraft.item.Item;
import net.minecraft.item.ItemGroups;
import net.minecraft.registry.Registries;
import net.minecraft.registry.Registry;
import net.minecraft.util.Identifier;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class LightningWandMod implements ModInitializer {

	public static final String MOD_ID = "lightningwand";
	public static final Logger LOGGER = LoggerFactory.getLogger(MOD_ID);

	public static final Item LIGHTNING_WAND = new LightningWandItem(
			new FabricItemSettings().maxCount(1)
	);

	@Override
	public void onInitialize() {
		Registry.register(
				Registries.ITEM,
				new Identifier(MOD_ID, "lightning_wand"),
				LIGHTNING_WAND
		);

		// Add the wand to the vanilla "Combat" creative inventory tab, right after the trident.
		ItemGroupEvents.modifyEntriesEvent(ItemGroups.COMBAT).register(entries ->
				entries.add(LIGHTNING_WAND)
		);

		LOGGER.info("[Lightning Wand] betoltve - keszen all a villamszorasra!");
	}
}
