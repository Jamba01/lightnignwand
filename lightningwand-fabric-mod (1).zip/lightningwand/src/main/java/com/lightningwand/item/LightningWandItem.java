package com.lightningwand.item;

import net.minecraft.entity.EntityType;
import net.minecraft.entity.LightningEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.sound.SoundCategory;
import net.minecraft.sound.SoundEvents;
import net.minecraft.util.Hand;
import net.minecraft.util.TypedActionResult;
import net.minecraft.util.hit.HitResult;
import net.minecraft.util.math.Vec3d;
import net.minecraft.world.RaycastContext;
import net.minecraft.world.World;

/**
 * A wand that strikes lightning wherever the player is looking when they right-click.
 */
public class LightningWandItem extends Item {

	/** How far (in blocks) the wand can reach. */
	private static final double RANGE = 50.0;

	/** Cooldown between uses, in ticks (20 ticks = 1 second). */
	private static final int COOLDOWN_TICKS = 20;

	public LightningWandItem(Settings settings) {
		super(settings);
	}

	@Override
	public TypedActionResult<ItemStack> use(World world, PlayerEntity user, Hand hand) {
		ItemStack stack = user.getStackInHand(hand);

		if (user.getItemCooldownManager().isCoolingDown(this)) {
			return TypedActionResult.pass(stack);
		}

		// Only spawn the lightning bolt on the server, otherwise it would happen twice
		// (once on the client, once on the server) and desync.
		if (!world.isClient) {
			Vec3d target = findTargetPos(world, user);

			LightningEntity bolt = EntityType.LIGHTNING_BOLT.create(world);
			if (bolt != null) {
				bolt.setPosition(target.x, target.y, target.z);

				// Mark the player as the "channeler" so kills/loot are credited to them,
				// just like the vanilla Channeling enchantment does.
				if (user instanceof ServerPlayerEntity serverPlayer) {
					bolt.setChanneler(serverPlayer);
				}

				world.spawnEntity(bolt);
			}

			world.playSound(
					null,
					user.getX(), user.getY(), user.getZ(),
					SoundEvents.ENTITY_LIGHTNING_BOLT_THUNDER,
					SoundCategory.PLAYERS,
					2.0f,
					1.0f
			);
		}

		user.getItemCooldownManager().set(this, COOLDOWN_TICKS);
		user.swingHand(hand, true);

		return TypedActionResult.success(stack, world.isClient());
	}

	/**
	 * Raycasts from the player's eyes along their look direction to find where the
	 * lightning bolt should land: the block they're looking at, or a point in the
	 * air at max range if nothing is in the way.
	 */
	private Vec3d findTargetPos(World world, PlayerEntity user) {
		Vec3d start = user.getEyePos();
		Vec3d look = user.getRotationVec(1.0f);
		Vec3d end = start.add(look.multiply(RANGE));

		HitResult hit = world.raycast(new RaycastContext(
				start,
				end,
				RaycastContext.ShapeType.OUTLINE,
				RaycastContext.FluidHandling.NONE,
				user
		));

		return hit.getType() != HitResult.Type.MISS ? hit.getPos() : end;
	}
}
